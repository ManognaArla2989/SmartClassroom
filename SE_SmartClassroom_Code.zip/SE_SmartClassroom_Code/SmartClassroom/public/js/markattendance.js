document.addEventListener("DOMContentLoaded", function () {
    const attendanceList = document.getElementById("attendance-list");
    const totalCount = document.getElementById("total-students");
    const presentCount = document.getElementById("present-students");
    const absentCount = document.getElementById("absent-students");
    
    let students = []; // Store fetched students data

    // Function to create and add an attendance card to the attendance list container
    function addAttendanceCard(student, attendance) {
        const template = document.createElement("template");
        template.innerHTML = `
            <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Name: <span class="student-name">${student.name}</span></h5>
                    <p class="card-text">Age: <span class="student-age">${student.age}</span></p>
                    <p class="card-text">Gender: <span class="student-gender">${student.gender}</span></p>
                    <div class="btn-group" role="group" aria-label="Attendance Buttons">
                        <button type="button" class="btn btn-success btn-attendance" data-id="${student.id}" data-attendance="Present">Present</button>
                        <button type="button" class="btn btn-danger btn-attendance" data-id="${student.id}" data-attendance="Absent">Absent</button>
                    </div>
                    <p class="card-text student-attendance">Attendance: <span class="attendance-status">${attendance || "N/A"}</span></p>
                </div>
            </div>
        </div>        
        `;
        attendanceList.appendChild(template.content);
    }

    // Function to display the list of students with attendance cards
    function displayStudents() {
        students.forEach((student, index) => {
            const attendance = student.attendance || "N/A";
            student.id = index; // Add an ID property to the student object for reference
            addAttendanceCard(student, attendance);
        });
    }

    // Function to fetch and store the list of students
    function fetchStudents() {
        fetch("/api/getStudents") // Use "getStudents" endpoint for fetching students data
            .then((res) => res.json())
            .then((data) => {
                if (data.students) {
                    students = data.students; // Store fetched students data
                    // Display students data on the room page
                    displayStudents();
                    // Update attendance count
                    updateAttendanceCount();
                } else {
                    console.error("Error fetching students data:", data.error);
                }
            })
            .catch((err) => {
                console.error("Error fetching students data:", err);
            });
    }

    // Call the function to fetch and display the students on page load
    fetchStudents();

    // Add event listeners for the "Tick" and "Cross" buttons
    document.addEventListener("click", function (event) {
        const target = event.target;
        if (target.classList.contains("btn-attendance")) {
            const id = parseInt(target.dataset.id);
            const attendanceStatus = target.dataset.attendance;
            students[id].attendance = attendanceStatus;
            updateAttendance();
            updateAttendanceCount();
            // Send a POST request to update the attendance status on the server
            fetch("/api/updateAttendance", {
                method: "POST",
                body: JSON.stringify({ id, attendance: attendanceStatus }),
                headers: {
                    "Content-Type": "application/json"
                }
            })
            .then((res) => res.json())
            .then((data) => {
                if (data.status === "success") {
                    console.log("Attendance status updated successfully!");
                } else {
                    console.error("Error updating attendance status:", data.error);
                }
            })
            .catch((err) => {
                console.error("Error updating attendance status:", err);
            });
        }
    });

    // Function to update the attendance cards
    function updateAttendance() {
        // Clear the attendance list container
        attendanceList.innerHTML = "";

        // Display the updated list of students with attendance cards
        displayStudents();
    }

    // Function to update the attendance count at the bottom
    function updateAttendanceCount() {
        const totalStudents = students.length;
        const presentStudents = students.filter((student) => student.attendance === "Present").length;
        const absentStudents = totalStudents - presentStudents;
        totalCount.textContent = totalStudents;
        presentCount.textContent = presentStudents;
        absentCount.textContent = absentStudents;
    }

    // Additional code for handling Save and Cancel buttons
    const btnSave = document.querySelector(".btn-save");
    const btnCancel = document.querySelector(".btn-cancel");

    btnSave.addEventListener("click", function () {
        // Create the document with attendance details and download it
        const attendanceData = generateAttendanceData();
        const blob = new Blob([attendanceData], { type: "text/plain" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "attendance_details.txt";
        a.click();
        URL.revokeObjectURL(url);
    });

    function generateAttendanceData() {
        // Generate the attendance details as a string
        let attendanceData = "Attendance Details:\n\n";
        students.forEach((student) => {
            const attendanceStatus = student.attendance || "N/A";
            attendanceData += `Name: ${student.name}, Age: ${student.age}, Gender: ${student.gender}, Attendance: ${attendanceStatus}\n`;
        });
        return attendanceData;
    }

    btnCancel.addEventListener("click", function () {
        // Reset attendance data and update the attendance list
        students.forEach((student) => {
            student.attendance = undefined;
        });
        updateAttendance();
        updateAttendanceCount();
    });
});
