document.addEventListener("DOMContentLoaded", function () {
    const addComplaintForm = document.querySelector(".report-form"); // Get the form element
    const complaintTypeInput = document.getElementById("complaint-type");
    const complaintDataInput = document.getElementById("complaint-data");

    addComplaintForm.addEventListener("submit", function (event) {
        event.preventDefault();

        // Get the values from the form inputs
        const complaintType = complaintTypeInput.value;
        const complaintData = complaintDataInput.value;

        // Create the complaint object to be sent to the server
        const complaint = {
            type: complaintType,
            data: complaintData
        };

        // Send a POST request to the server to add the complaint
        fetch("/api/addcomplaint", {
            method: "POST",
            body: JSON.stringify(complaint),
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then((res) => res.json())
        .then((data) => {
            if (data.status === "success") {
                // Handle success response
                alert(data.success); // Show a success message (You can update this with a proper UI element)
                addComplaintForm.reset(); // Clear the form after successful submission
            } else {
                // Handle error response
                alert(data.error); // Show an error message (You can update this with a proper UI element)
            }
        })
        .catch((err) => {
            // Handle any network or server error
            console.error("Error:", err);
        });
    });
});
