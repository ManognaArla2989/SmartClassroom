document.addEventListener("DOMContentLoaded", function () {
    const addStudentForm = document.getElementById("add-student-form");
    const cancelBtn = document.getElementById("cancel-btn");

    addStudentForm.addEventListener("submit", function (event) {
        event.preventDefault();
        const name = document.getElementById("name").value;
        const age = parseInt(document.getElementById("age").value);
        const gender = document.getElementById("gender").value;

        // Create the student object to be sent to the server
        const student = {
            name: name,
            age: age,
            gender: gender
        };

        // Send a POST request to the server to add the student
        fetch("/api/addstudent", {
            method: "POST",
            body: JSON.stringify(student),
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then((res) => res.json())
        .then((data) => {
            if (data.status === "success") {
                // Handle success response
                alert(data.success); // Show a success message (You can update this with a proper UI element)
                addStudentForm.reset(); // Clear the form after successful submission
            } else {
                // Handle error response
                alert(data.error); // Show an error message (You can update this with a proper UI element)
            }
        })
        .catch((err) => {
            // Handle any network or server error
            console.error("Error:", err);
        });
    });

    // Cancel button click event to go back to the room.ejs page
    cancelBtn.addEventListener("click", function () {
        window.location.href = "/room"; // Replace "/room" with the actual URL of your room.ejs file
    });
});
