// room.js

// Function to create and add a student card to the student list container
function addStudentCard(student) {
    const template = document.createElement("template");
    template.innerHTML = `
        <div class="card student-card mb-3">
            <div class="card-body">
                <h5 class="card-title">Name: <span class="student-name">${student.name}</span></h5>
                <p class="card-text">Age: <span class="student-age">${student.age}</span></p>
                <p class="card-text">Gender: <span class="student-gender">${student.gender}</span></p>
                <button class="btn btn-danger remove-student-btn" data-id="${student.id}">Remove Student</button>
            </div>
        </div>
    `;
    document.getElementById("student-list").appendChild(template.content);
}

// Function to create and add a complaint card to the complaints list container
function addComplaintCard(complaint) {
    const template = document.createElement("template");
    template.innerHTML = `
        <div class="card complaint-card mb-3">
            <div class="card-body">
                <h5 class="card-title">Type: <span class="complaint-type">${complaint.type}</span></h5>
                <p class="card-text">Data: <span class="complaint-data">${complaint.data}</span></p>
                <button class="btn btn-primary resolve-complaint-btn" data-id="${complaint.id}">Resolve Issue</button>
            </div>
        </div>
    `;
    document.getElementById("complaintsList").appendChild(template.content);
}

// Function to display the list of students
function displayStudents(students) {
    students.forEach((student) => addStudentCard(student));
}

// Function to display the list of complaints
function displayComplaints(complaints) {
    complaints.forEach((complaint) => addComplaintCard(complaint));
}

// Function to remove a student from the database
function removeStudent(studentId) {
    fetch("/api/removeStudent", {
        method: "POST",
        body: JSON.stringify({ id: studentId }),
        headers: {
            "Content-Type": "application/json",
        },
    })
    .then((response) => response.json())
    .then((data) => {
        console.log("Student removed successfully:", data);
        // Optionally, you can update the UI here to remove the student card from the list
        location.reload();
    })
    .catch((error) => {
        console.error("Error removing student:", error);
    });
}

// Function to resolve a complaint from the database
function resolveComplaint(complaintId) {
    fetch("/api/resolveIssue", {
        method: "POST",
        body: JSON.stringify({ id: complaintId }),
        headers: {
            "Content-Type": "application/json",
        },
    })
    .then((response) => response.json())
    .then((data) => {
        console.log("Complaint resolved successfully:", data);
        // Optionally, you can update the UI here to remove the complaint card from the list
        location.reload();
    })
    .catch((error) => {
        console.error("Error resolving complaint:", error);
    });
}

document.addEventListener("DOMContentLoaded", function () {
    // Fetch the data from the server to display students and complaints
    fetch("/api/getStudents") // Replace "/api/students" with the actual route to fetch students data
        .then((response) => response.json())
        .then((data) => {
            const students = data.students; // Assuming the server returns an object with a "students" property containing an array of students
            displayStudents(students);
        })
        .catch((error) => {
            console.error("Error fetching students:", error);
        });

    fetch("/api/getComplaints") // Replace "/api/complaints" with the actual route to fetch complaints data
        .then((response) => response.json())
        .then((data) => {
            const complaints = data.complaints; // Assuming the server returns an object with a "complaints" property containing an array of complaints
            displayComplaints(complaints);
        })
        .catch((error) => {
            console.error("Error fetching complaints:", error);
        });

    // Handle click events on student dropdown
    document.getElementById("student-list").addEventListener("click", function (event) {
        const target = event.target;
        if (target.classList.contains("remove-student-btn")) {
            const studentId = parseInt(target.dataset.id);
            removeStudent(studentId);
        }
    });

    // Handle click events on complaint dropdown
    document.getElementById("complaintsList").addEventListener("click", function (event) {
        const target = event.target;
        if (target.classList.contains("resolve-complaint-btn")) {
            const complaintId = parseInt(target.dataset.id);
            resolveComplaint(complaintId);
        }
    });
});
