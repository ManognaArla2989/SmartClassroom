// Sample file data (Replace this with your actual file data)
const filesData = [
    { name: 'File 1', url: 'https://example.com/file1.pdf' },
    { name: 'File 2', url: 'https://example.com/file2.jpg' },
    { name: 'File 3', url: 'https://example.com/file3.docx' },
  ];
  
  // Function to display files in the Files Display Section
  function displayFiles() {
    const filesDisplaySection = document.querySelector('.files-storage-section');
  
    // Clear the existing content in the section
    filesDisplaySection.innerHTML = '';
  
    // Create and append elements for each file
    filesData.forEach((file) => {
      const fileLink = document.createElement('a');
      fileLink.href = file.url;
      fileLink.target = '_blank';
      fileLink.innerText = file.name;
  
      const fileItem = document.createElement('p');
      fileItem.appendChild(fileLink);
  
      filesDisplaySection.appendChild(fileItem);
    });
  }
  
  // Call the displayFiles function when the page loads
  document.addEventListener('DOMContentLoaded', displayFiles);
  