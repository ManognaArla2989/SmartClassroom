const db = require("../routes/db-config");

const getComplaints = async (req, res) => {
  try {
    db.query("SELECT * FROM complaintsdb", (err, result) => {
      if (err) {
        console.error("Error fetching complaints:", err);
        return res.json({ status: "error", error: "Failed to fetch complaints." });
      }
      const complaints = result;
      return res.json({ status: "success", complaints });
    });
  } catch (err) {
    console.error("Error:", err);
    return res.json({ status: "error", error: "Something went wrong." });
  }
};

module.exports = getComplaints;
