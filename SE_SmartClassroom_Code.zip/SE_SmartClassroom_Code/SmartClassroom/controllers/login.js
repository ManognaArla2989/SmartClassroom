const jwt = require("jsonwebtoken");
const db = require("../routes/db-config");
const bcrypt = require("bcryptjs");

const login = async (req, res) => {
    const {email,password} = req.body;
    if(!email || !password) return res.json({status:"error", error:"Please enter email & password!!"});
    else{
        db.query('SELECT * FROM rooms WHERE roomnum = ?', [email], async (Err, result) => {
            if(Err) throw Err;
            if(!result[0] || !await bcrypt.compare(password, result[0].password)){
                console.log(password);
                return res.json({status:"error", error:"Incorrect Credentials"});
            }
            else{
                const token = jwt.sign({id: result[0].id},process.env.JWT_SECRET, {
                    expiresIn: process.env.JWT_EXPIRES
                });
                const cookieOptions = {
                    expiresIn: new Date(Date.now()+process.env.COOKIE_EXPIRES * 24 * 60 * 60 * 1000),
                    httpOnly: true
                }
                res.cookie("userregistered",token,cookieOptions);
                return res.json({status: "success",success: "Entered the room"})
            }
        })
    }
}

module.exports = login;