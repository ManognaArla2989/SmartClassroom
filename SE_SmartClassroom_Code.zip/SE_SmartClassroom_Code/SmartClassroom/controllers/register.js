const db = require("../routes/db-config");
const bcrypt = require("bcryptjs");

const register = async (req, res) => {
    const {email,password:Npassword} = req.body;
    if(!email || !Npassword) return res.json({status:"error", error:"Please enter email & password!!"});
    else{
        db.query('SELECT roomnum FROM rooms WHERE roomnum = ?',[email],async (err,result) =>{
            if (err) throw err;
            if(result[0]) return res.json({status:"error", error:"Room name alread taken."})
            else{
                const password = await bcrypt.hash(Npassword, 8);
                console.log(password);
                db.query('INSERT INTO rooms SET ?', {roomnum: email, password:password},(error,results) => {
                    if(error) throw error;
                    return res.json({status:"success", success:"Room created"})
                })
            }
        })
    }
}

module.exports = register;