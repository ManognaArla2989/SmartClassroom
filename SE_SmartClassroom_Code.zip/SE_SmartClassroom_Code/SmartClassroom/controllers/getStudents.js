const db = require("../routes/db-config");

const getStudents = async (req, res) => {
  try {
    db.query("SELECT * FROM studentdb", (err, result) => {
      if (err) {
        console.error("Error fetching students:", err);
        return res.json({ status: "error", error: "Failed to fetch students." });
      }
      const students = result;
      return res.json({ status: "success", students });
    });
  } catch (err) {
    console.error("Error:", err);
    return res.json({ status: "error", error: "Something went wrong." });
  }
};

module.exports = getStudents;
