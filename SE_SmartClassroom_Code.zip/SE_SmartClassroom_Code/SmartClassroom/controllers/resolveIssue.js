const db = require("../routes/db-config");

const resolveIssue = async (req, res) => {
  try {
    const complaintId = req.body.id;

    // Check if the complaint exists in the database
    db.query("SELECT * FROM complaintsdb WHERE id=?", [complaintId], (err, result) => {
      if (err) {
        console.error("Error fetching complaint:", err);
        return res.status(500).json({ status: "error", error: "Failed to fetch complaint." });
      }

      if (result.length === 0) {
        return res.status(404).json({ status: "error", error: "Complaint not found." });
      }

      // Complaint exists, so proceed with resolving the issue
      // (You can add your custom logic here to update the complaint status or mark it as resolved)
      // For example, to remove the complaint from the database, you can use the following query:
      db.query("DELETE FROM complaintsdb WHERE id=?", [complaintId], (err, result) => {
        if (err) {
          console.error("Error deleting complaint:", err);
          return res.status(500).json({ status: "error", error: "Failed to resolve the complaint." });
        }
        
        return res.json({ status: "success", message: "Complaint resolved successfully." });
      });
    });
  } catch (err) {
    console.error("Error:", err);
    return res.status(500).json({ status: "error", error: "Something went wrong." });
  }
};

module.exports = resolveIssue;
