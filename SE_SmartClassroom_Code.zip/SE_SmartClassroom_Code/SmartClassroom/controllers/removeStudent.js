const db = require("../routes/db-config");

const removeStudent = async (req, res) => {
  try {
    const studentId = req.body.id;
    
    // Check if the student exists in the database
    db.query("SELECT * FROM studentdb WHERE id=?", [studentId], (err, result) => {
      if (err) {
        console.error("Error fetching student:", err);
        return res.json({ status: "error", error: "Failed to fetch student." });
      }

      if (result.length === 0) {
        return res.json({ status: "error", error: "Student not found." });
      }

      // Student exists, so proceed with removing the student
      db.query("DELETE FROM studentdb WHERE id=?", [studentId], (err, result) => {
        if (err) {
          console.error("Error removing student:", err);
          return res.json({ status: "error", error: "Failed to remove student." });
        }

        return res.json({ status: "success", message: "Student removed successfully." });
      });
    });
  } catch (err) {
    console.error("Error:", err);
    return res.json({ status: "error", error: "Something went wrong." });
  }
};

module.exports = removeStudent;
