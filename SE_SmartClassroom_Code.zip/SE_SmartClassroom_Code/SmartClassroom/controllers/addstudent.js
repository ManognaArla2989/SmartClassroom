// addstudent.js (controller)
const db = require("../routes/db-config");

const addStudent = async (req, res) => {
    const { name, age, gender } = req.body;

    try {
        // Check if a student with the same name already exists
        db.query(
            "SELECT * FROM studentdb WHERE name = ?",
            [name],
            (err, result) => {
                if (err) {
                    console.error("Error checking for existing student:", err);
                    return res.json({ status: "error", error: "Failed to add student." });
                }

                if (result.length > 0) {
                    // A student with the same name already exists
                    return res.json({ status: "error", error: "Student already exists." });
                }

                // Insert the new student into the database
                db.query(
                    "INSERT INTO studentdb (name, age, gender) VALUES (?, ?, ?)",
                    [name, age, gender],
                    (err, result) => {
                        if (err) {
                            console.error("Error adding student:", err);
                            return res.json({ status: "error", error: "Failed to add student." });
                        }
                        console.log("Student added:", result);
                        return res.json({ status: "success", success: "Student added successfully." });
                    }
                );
            }
        );
    } catch (err) {
        console.error("Error:", err);
        return res.json({ status: "error", error: "Something went wrong." });
    }
};

module.exports = addStudent;
