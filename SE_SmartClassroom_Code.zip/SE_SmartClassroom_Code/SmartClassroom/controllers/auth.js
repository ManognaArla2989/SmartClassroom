
const express = require("express");
const register = require("./register");
const login = require("./login");
const addstudent = require("./addstudent"); // Add this line to import the addstudent controller
const addcomplaint = require("./addcomplaint");
const getStudents = require("./getStudents");
const getComplaints = require("./getComplaints");
const removeStudent = require("./removeStudent");
const resolveIssue = require("./resolveIssue");
const router = express.Router();

router.post("/register", register);
router.post("/login", login);
router.post("/addstudent", addstudent); 
router.post("/addcomplaint", addcomplaint);
router.get("/getStudents", getStudents); 
router.get("/getComplaints", getComplaints);
router.post("/removeStudent", removeStudent);
router.post("/resolveIssue", resolveIssue);

module.exports = router;
