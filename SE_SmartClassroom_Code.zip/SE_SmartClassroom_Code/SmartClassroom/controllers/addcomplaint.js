// addComplaint.js (controller)
const db = require("../routes/db-config");

const addComplaint = async (req, res) => {
    const { type, data } = req.body;

    try {
        db.query(
            "INSERT INTO complaintsdb (type, data) VALUES (?, ?)",
            [type, data ],
            (err, result) => {
                if (err) {
                    console.error("Error adding complaint:", err);
                    return res.json({ status: "error", error: "Failed to add complaint." });
                }
                console.log("Complaint added:", result);
                return res.json({ status: "success", success: "Complaint added successfully." });
            }
        );
    } catch (err) {
        console.error("Error:", err);
        return res.json({ status: "error", error: "Something went wrong." });
    }
};

module.exports = addComplaint;
