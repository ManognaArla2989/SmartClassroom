const express = require("express");
const router = express.Router();

router.get("/", (req,res) => {
    res.render("index");
})

router.get("/register", (req,res) => {
    res.sendFile("register.html",{root:"./public"});
})

router.get("/login", (req,res) => {
    res.sendFile("login.html",{root:"./public"});
})

// Add the route for the room page
router.get("/room", (req, res) => {
    res.render("room");
});

router.get("/room/mark-attendance", (req,res) => {
    res.sendFile("mark-attendance.html",{root:"./public/room"});
})

router.get("/room/control-appliances", (req,res) => {
    res.sendFile("control-appliances.html",{root:"./public/room"});
})

router.get("/room/files-storage", (req,res) => {
    res.sendFile("files-storage.html",{root:"./public/room"});
})

router.get("/room/report-problem", (req,res) => {
    res.sendFile("report-problem.html",{root:"./public/room"});
})

router.get("/room/addstudent", (req,res) => {
    res.sendFile("addstudent.html",{root:"./public/room"});
})

module.exports = router;